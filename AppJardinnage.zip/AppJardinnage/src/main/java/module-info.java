module com.example.appjardinnage {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.appjardinnage to javafx.fxml;
    exports com.example.appjardinnage.view;
}