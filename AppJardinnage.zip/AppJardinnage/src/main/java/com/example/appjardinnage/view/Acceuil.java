package com.example.appjardinnage.view;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Box;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.geometry.Pos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Acceuil extends Application {
    GridPane menuLate = new GridPane();
    @Override
    public void start(Stage stage) throws IOException {
        Image meteo = new Image("C:\\Users\\ahcen\\Downloads\\Capture.PNG");
        ImageView meteo1 = new ImageView();
        meteo1.setImage(meteo);
        meteo1.setFitHeight(100);
        meteo1.setFitWidth(100);
        List<Button> Lmois = new ArrayList(12);
        Lmois.add(new Button("Janvier"));
        Lmois.add(new Button("Fevrier"));
        Lmois.add(new Button("Mars"));
        Lmois.add(new Button("Avril"));
        Lmois.add(new Button("Mai"));
        Lmois.add(new Button("Juin"));
        Lmois.add(new Button("Juillet"));
        Lmois.add(new Button("Aout"));
        Lmois.add(new Button("Septembre"));
        Lmois.add(new Button("Octobre"));
        Lmois.add(new Button("Novombre"));
        Lmois.add(new Button("Decembre"));

        VBox llmois = new VBox();
        llmois.getChildren().addAll(Lmois);

        



        Hyperlink Ajdhui = new Hyperlink("Aujourd'hui");
        Hyperlink ctsmn = new Hyperlink("Cette-semaine");
        Hyperlink cmois = new Hyperlink("Ce Mois-ci");
        Hyperlink plnte = new Hyperlink("⚘ Plante");
        Hyperlink sclre = new Hyperlink("Scolaire");

        VBox ml = new VBox(15);
        ml.setBackground(new Background(new BackgroundFill(Color.GREEN,null,null)));
        ml.getChildren().addAll(Ajdhui,ctsmn,cmois,plnte,sclre);
        menuLate.setPrefSize(50,50);
        menuLate.add(ml,0,10);


        HBox jours = new HBox(0);
        Button lun = new Button("lun");
        Button mar = new Button("mar");
        Button mer = new Button("mer");
        Button jeu = new Button("jeu");
        Button ven = new Button("ven");
        Button sam = new Button("sam");
        Button dim = new Button("dim");

        jours.getChildren().addAll(lun,mar,mer,jeu,ven,sam,dim);


        HBox l1 = new HBox(0);
        Text mois = new Text("Mois");
        Button flech = new Button("⏷");
        l1.getChildren().addAll(mois,flech);
        //l1.setAlignment(Pos.CENTER_LEFT);
        //l1.getChildren().add(menuLate);
        menuLate.add(l1,2,0);
        menuLate.add(meteo1,0,0);
        menuLate.add(jours,2,2);

        Text date = new Text("      Lundi 12 Janvier 2024");
        CheckBox a = new CheckBox();
        Text tch = new Text("       visite de jardin botanique");
        CheckBox b = new CheckBox();
        Text tch2 = new Text("      Cours Magistral");
        CheckBox c = new CheckBox();
        Text stch = new Text("          revoir taupologie plante");
        CheckBox d = new CheckBox();
        Text tch3 = new Text("      Arroser plante");
        CheckBox e1 = new CheckBox();
        Text tch4 = new Text("      Rampotage");


        menuLate.add(date,2,3);

        menuLate.add(tch,2,4);
        menuLate.add(a,2,4);

        menuLate.add(tch2,2,5);
        menuLate.add(b,2,5);

        menuLate.add(stch,2,6);
        menuLate.add(c,2,6);

        menuLate.add(tch3,2,7);
        menuLate.add(d,2,7);

        menuLate.add(tch4,2,8);
        menuLate.add(e1,2,8);




        stage.setTitle("jardinnage");
        Scene myscene = new Scene(menuLate, 400, 450);
        stage.setScene(myscene);
        stage.show();





        /***navigation entre page***/

        flech.setOnAction(event->{
            Mois m1 = new Mois();
            try {
                m1.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

       plnte.setOnAction(event ->{
            Plante page2 = new Plante();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        cmois.setOnAction(event ->{
            ceMois page2 = new ceMois();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        flech.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                menuLate.add(llmois,2,5);}
        });

        flech.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                llmois.getChildren().clear();

            }
        });

        sclre.setOnAction(event ->{
            TacheScolaire nPage = new TacheScolaire();
            try {
                nPage.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });






    }

    /*public void addNewButton(){
        new ctSmn = new Hyperlink("cette Semaine");
        menuLate.add(,0,16);
    }*/

    public static void main(String[] args) {
        launch(args);
    }
}