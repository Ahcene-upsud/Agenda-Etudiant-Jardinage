package com.example.appjardinnage.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Detail_tache_orange2 {
    GridPane menuLate = new GridPane();

    public void start(Stage stage) throws Exception {
        stage.setTitle("ceMois");

        Image meteo = new Image("C:\\Users\\ahcen\\Downloads\\Capture.PNG");
        ImageView meteo1 = new ImageView();
        meteo1.setImage(meteo);
        meteo1.setFitHeight(100);
        meteo1.setFitWidth(100);

        Text field = new Text("Tache Orange : ");

        Hyperlink Ajdhui = new Hyperlink(" Aujourd'hui");
        Hyperlink ctsmn = new Hyperlink("Cette-semaine");
        Hyperlink cmois = new Hyperlink("Ce Mois-ci");
        Hyperlink plnte = new Hyperlink("⚘ Plante");
        Hyperlink sclre = new Hyperlink("Scolaire");
        //Hyperlink lstplnt = new Hyperlink("Liste Plante");
        //Hyperlink dtail = new Hyperlink("Detail ");
        //Hyperlink tach = new Hyperlink("Tache");




        VBox ml = new VBox(1);

        ml.setBackground(new Background(new BackgroundFill(Color.GREEN,null,null)));
        ml.getChildren().addAll(Ajdhui,ctsmn,cmois,plnte,sclre);
        menuLate.setPrefSize(50,50);
        menuLate.add(ml,0,10);
        menuLate.add(meteo1,0,0);
        menuLate.add(field,2,0);

        Button tache1 = new Button("tache1");
        Button Stache1 = new Button("S/tache2");
        Button Stache2 = new Button("S/tache3");


        menuLate.add(tache1,2,3);
        menuLate.add(Stache1,2,4);
        menuLate.add(Stache2,2,5);

        Text crSt = new Text("Sous Tache :");
        TextField nom = new TextField("nom");
        TextField date = new TextField("Date");
        Button stch = new Button("Creer Sous Tache");
        menuLate.add(crSt,2,6);
        menuLate.add(nom,2,7);
        menuLate.add(date,2,8);
        menuLate.add(stch,2,9);
        System.out.println("skrf");

        Scene myscene1 = new Scene(menuLate, 350, 450);
        stage.setScene(myscene1);

        /***set action **/


        plnte.setOnAction(event ->{
            Plante page2 = new Plante();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        cmois.setOnAction(event ->{
            ceMois page2 = new ceMois();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });


    }
}
