package com.example.appjardinnage.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.FileChooser;

import java.io.File;

public class AjouterPlante {
    GridPane menuLate = new GridPane();

    public void start(Stage stage) throws Exception {

        Image meteo = new Image("C:\\Users\\ahcen\\Downloads\\Capture.PNG");
        Image imagephoto = new Image("C:\\Users\\ahcen\\Downloads\\photoapp.PNG");
        ImageView meteo1 = new ImageView();
        ImageView imgphoto = new ImageView();
        imgphoto.setFitWidth(50); // Définir la largeur de l'image
        imgphoto.setFitHeight(50);
        meteo1.setImage(meteo);
        imgphoto.setImage(imagephoto);
        meteo1.setFitHeight(100);
        meteo1.setFitWidth(100);


        Text field = new Text("Ajouter une Plante  : ");

        Hyperlink Ajdhui = new Hyperlink(" Aujourd'hui");
        Hyperlink ctsmn = new Hyperlink("Cette-semaine");
        Hyperlink cmois = new Hyperlink("Ce Mois-ci");
        Hyperlink plnte = new Hyperlink("⚘ Plante");
        Hyperlink sclre = new Hyperlink("Scolaire");
        //Hyperlink lstplnt = new Hyperlink("Liste Plante");
        //Hyperlink dtail = new Hyperlink("Detail ");

        VBox ml1 = new VBox(0);
        VBox ml = new VBox(1);
        ml.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        ml.getChildren().addAll(Ajdhui, ctsmn, cmois, plnte, sclre);

        TextField nomPlante = new TextField("Nom de la plante");
        TextField nbArrosage = new TextField("nombre arrosage");
        TextField LumSom = new TextField("Lumiere/Sombre");
        Button cree = new Button("Cree");
        Button photo = new Button("");
        photo.setGraphic(imgphoto);
        Button vnom = new Button("✔");
        Button vnom1 = new Button("✔");
        Button vnom2 = new Button("✔");
        Button vnom3 = new Button("✔");


        menuLate.add(nomPlante,2,3);
        menuLate.add(nbArrosage,2,4);
        menuLate.add(LumSom,2,5);
        menuLate.add(cree,3,7);
        menuLate.add(photo,2,7);

        menuLate.add(vnom,3,3);
        menuLate.add(vnom1,3,4);
        menuLate.add(vnom2,3,5);
        menuLate.add(vnom3,3,6);



        menuLate.setPrefSize(50,50);
        menuLate.add(ml,0,10);
        menuLate.add(meteo1,0,0);
        menuLate.add(field,2,0);

        /***navigation entre page***/

        photo.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showOpenDialog(stage);

            // Vérifier si un fichier a été sélectionné
            if (selectedFile != null) {
                System.out.println("Fichier sélectionné : " + selectedFile.getAbsolutePath());
            }
        });


        /*photo.setOnAction(event ->{
            Les_suivi_orange p1 = new Les_suivi_orange();
            try {
                p1.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });*/

        Ajdhui.setOnAction(event -> {
            Acceuil page2 = new Acceuil();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        cmois.setOnAction(event -> {
            ceMois page2 = new ceMois();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        sclre.setOnAction(event -> {
            TacheScolaire nPage = new TacheScolaire();
            try {
                nPage.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });




        Scene myscene1 = new Scene(menuLate, 350, 450);
        stage.setScene(myscene1);
    }
}
