package com.example.appjardinnage.view;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class Plante {

    GridPane menuLate = new GridPane();

  /**** public void click(List<Button>l){
       for(int i=0 ;i<=l.size();i++){
           l.get(i).setOnAction(event -> {
               detailPlante page2 = new detailPlante();
               try {
                   page2.start(stage);
               } catch (Exception e) {
                   throw new RuntimeException(e);
               }
           }););
       }
   }**/
    public Button getPlante(Button g,List<Button> h) {
        for (int i = 0; i <= h.size(); i++) {
            if (h.get(i) == g) {
                return h.get(i);
            }
        }
        return h.get(0);
    }
    public void start(Stage stage) throws Exception {

        stage.setTitle("Plante");

        List<Button> plante = new ArrayList<>();
        plante.add(new Button("Orangier ▶"));
        plante.add(new Button("pommier ▶"));
        plante.add(new Button("Ajouter une Plante ▶"));


        stage.setTitle("Plante");

        Image meteo = new Image("C:\\Users\\ahcen\\Downloads\\Capture.PNG");
        ImageView meteo1 = new ImageView();
        meteo1.setImage(meteo);
        meteo1.setFitHeight(100);
        meteo1.setFitWidth(100);

        Text field = new Text("Vos Plantes : ");

        Hyperlink Ajdhui = new Hyperlink(" Aujourd'hui");
        Hyperlink ctsmn = new Hyperlink("Cette-semaine");
        Hyperlink cmois = new Hyperlink("Ce Mois-ci");
        Hyperlink plnte = new Hyperlink("⚘ Plante");
        Hyperlink sclre = new Hyperlink("Scolaire");
        //Hyperlink lstplnt = new Hyperlink("Liste Plante");


        VBox ml = new VBox(15);

        VBox lstPlante = new VBox();
        lstPlante.setSpacing(10); // Définit l'espace vertical entre les boutons
        lstPlante.setPadding(new Insets(10));
        lstPlante.getChildren().addAll(plante);

        ml.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        ml.getChildren().addAll(Ajdhui, ctsmn, cmois, plnte, sclre);
        menuLate.setPrefSize(50, 50);
        menuLate.add(ml, 0, 10);
        menuLate.add(meteo1, 0, 0);
        menuLate.add(field, 4, 0);
        menuLate.add(lstPlante, 10, 5);

        Scene myscene1 = new Scene(menuLate, 350, 450);
        stage.setScene(myscene1);

        /***action***/
        Ajdhui.setOnAction(event -> {
            Acceuil page2 = new Acceuil();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        cmois.setOnAction(event -> {
            ceMois page2 = new ceMois();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        sclre.setOnAction(event -> {
            TacheScolaire nPage = new TacheScolaire();
            try {
                nPage.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        plante.get(0).setOnAction(event -> {
            detailOrange dtl = new detailOrange();
            try{
                dtl.start(stage);
            } catch (Exception e){
                throw new RuntimeException(e);
            }
        });
        plante.get(2).setOnAction(event -> {
            AjouterPlante dtl = new AjouterPlante();
            try{
                dtl.start(stage);
            } catch (Exception e){
                throw new RuntimeException(e);
            }
        });


    }

}
