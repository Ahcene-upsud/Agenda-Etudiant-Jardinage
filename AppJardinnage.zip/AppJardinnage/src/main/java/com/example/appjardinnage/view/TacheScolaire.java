package com.example.appjardinnage.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class TacheScolaire {
    List<Button> lTache = new ArrayList<>();
    GridPane menuLate = new GridPane();

    public void start(Stage stage) throws Exception {
        stage.setTitle("Scolaire");

        Image meteo = new Image("C:\\Users\\ahcen\\Downloads\\Capture.PNG");
        ImageView meteo1 = new ImageView();
        meteo1.setImage(meteo);
        meteo1.setFitHeight(100);
        meteo1.setFitWidth(100);

        Text field = new Text("Vos Taches : ");

        Hyperlink Ajdhui = new Hyperlink(" Aujourd'hui");
        Hyperlink ctsmn = new Hyperlink("Cette-semaine");
        Hyperlink cmois = new Hyperlink("Ce Mois-ci");
        Hyperlink plnte = new Hyperlink("⚘ Plante");
        Hyperlink sclre = new Hyperlink("Scolaire");
        //Hyperlink tache2 = new Hyperlink("tache");


        VBox zoneTache = new VBox();
        zoneTache.getChildren().addAll(lTache);
        menuLate.add(zoneTache,1,3);

        Text tache = new Text("Tache:");
        TextField nomTache = new TextField("Nom");
        Button vnom = new Button("✔");
        TextField Date = new TextField("Date");
        Button vDate = new Button("✔");
        Text importance = new Text("Importante:");
        Button oui = new Button("oui");
        Button non = new Button("non");
        Button creer = new Button("créer");
        menuLate.add(tache,2,5);
        menuLate.add(nomTache,2,6);
        menuLate.add(vnom,3,6);
        menuLate.add(Date,2,7);
        menuLate.add(vDate,3,7);
        menuLate.add(importance,2,8);
        menuLate.add(oui,3,8);
        menuLate.add(non,4,8);
        menuLate.add(creer,4,11);


        VBox ml = new VBox(15);
        ml.setBackground(new Background(new BackgroundFill(Color.GREEN,null,null)));
        ml.getChildren().addAll(Ajdhui,ctsmn,cmois,plnte,sclre);

        menuLate.setPrefSize(50,50);
        menuLate.add(ml,0,10);
        menuLate.add(meteo1,0,0);
        menuLate.add(field,2,0);



        Scene myscene1 = new Scene(menuLate, 350, 450);
        stage.setScene(myscene1);




        /**action**/
        Ajdhui.setOnAction(event ->{
            Acceuil page2 = new Acceuil();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        plnte.setOnAction(event ->{
            Plante page2 = new Plante();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        cmois.setOnAction(event ->{
            ceMois page2 = new ceMois();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });




    }
}
