package com.example.appjardinnage.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ceMois {
    GridPane menuLate = new GridPane();

    public void start(Stage stage) throws Exception {
        stage.setTitle("ceMois");

        Image meteo = new Image("C:\\Users\\ahcen\\Downloads\\Capture.PNG");
        ImageView meteo1 = new ImageView();
        meteo1.setImage(meteo);
        meteo1.setFitHeight(100);
        meteo1.setFitWidth(100);

        Text field = new Text("Ce Mois-ci : ");

        Hyperlink Ajdhui = new Hyperlink(" Aujourd'hui");
        Hyperlink ctsmn = new Hyperlink("Cette-semaine");
        Hyperlink cmois = new Hyperlink("Ce Mois-ci");
        Hyperlink plnte = new Hyperlink("⚘ Plante");
        Hyperlink sclre = new Hyperlink("Scolaire");

        Button smn1 = new Button("Semaine1");
        Button smn2 = new Button("Semaine2");
        Button smn3 = new Button("Semaine3");
        Button smn4 = new Button("Semaine4");

        VBox ml = new VBox(15);

        ml.setBackground(new Background(new BackgroundFill(Color.GREEN,null,null)));
        ml.getChildren().addAll(Ajdhui,ctsmn,cmois,plnte,sclre);
        menuLate.setPrefSize(50,50);
        menuLate.add(ml,0,10);
        menuLate.add(meteo1,0,0);
        menuLate.add(field,4,0);

        menuLate.add(smn1,3,5);
        menuLate.add(smn2,3,7);
        menuLate.add(smn3,9,5);
        menuLate.add(smn4,9,7);

        Scene myscene1 = new Scene(menuLate, 350, 450);
        stage.setScene(myscene1);

        /***sf***/
        Ajdhui.setOnAction(event ->{
            Acceuil page2 = new Acceuil();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        plnte.setOnAction(event ->{
            Plante page2 = new Plante();
            try {
                page2.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        sclre.setOnAction(event ->{
            TacheScolaire nPage = new TacheScolaire();
            try {
                nPage.start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });


    }

}
