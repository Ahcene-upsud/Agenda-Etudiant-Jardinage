package com.example.appjardinnage.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class Mois {

    public void start(Stage stage) throws IOException {
        VBox mois = new VBox();
        Button janvier = new Button("janvier");
        Button fevrier = new Button("Fevrier");
        Button mars = new Button("Mars");
        Button avril = new Button("Avril");
        Button mai = new Button("Mai");
        Button juin = new Button("Juin");
        Button juillet  = new Button("Juillet");
        Button aout = new Button("Aout");
        Button septembre = new Button("Septembre");
        Button octobre = new Button("Octobre");
        Button novembre = new Button("Novembre");
        Button decembre = new Button("Decembre");

        System.out.println("wdjh");


        mois.getChildren().addAll(janvier,fevrier,mars,avril,mai,juin,juillet,aout,septembre,octobre,novembre,decembre);
        Scene myscene = new Scene(mois, 400, 450);
        stage.setScene(myscene);
        stage.show();
    }
}
